Introduction to Time Series Forecasting with Python
===================================================

README
------

Welcome to Introduction to Time Series Forecasting with Python!

Your package contains:

1. README (this file)
	README.txt
2. The Ebook:
	time_series_forecasting_with_python.pdf
3. Code Recipes:
	code/

The code directory provides access to all of the data and code examples used in the book.

Any questions at all, contact me direction via email: jason@MachineLearningMastery.com

Kind Regards,

Jason.
